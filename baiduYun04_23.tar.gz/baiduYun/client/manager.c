#include "head.h"

void M_Printf(){
	printf("\t\t\t   管理员界面\n");
	printf("\t\t\t  1.查询用户 \n");
	printf("\t\t\t  2.查看所有用户信息\n ");
	printf("\t\t\t  3.删除某用户信息\n ");
	printf("\t\t\t  4.修改用户拥有容量\n ");
	printf("\t\t\t  5.退出\n ");	
	printf("\t\t\t  请输入你所要操作的项目：");
}
void searchUser(int sfd){
	printf("请输入你要查找的姓名：\n");
	char name[20]={0};
	scanf("%s",name);
	send(sfd,name,strlen(name),0);
}
void deleteUser(int sfd){
	printf("请输入你要删除的名称:\n");
	char name[20]={0};
	scanf("%s",name);
	send(sfd,name,strlen(name),0);
}
void updateUserCapacity(int sfd){
	int n=0;
	int id=0;
	printf("请输入要修改的id\n");
	scanf_num(&id);
	send(sfd,&id,4,0);
	printf("请输入2G的倍数如：2\n");
	scanf("%d",&n);
	send(sfd,&n,4,0);
}
void manager(int sfd){
	int op=0;
	char buf[10000]={0};
	int len=0;
	int ret=0;
	int sum=0;
start:
	M_Printf();
	scanf_num(&op);
	send(sfd,&op,4,0);
	switch(op){
		case 1: searchUser(sfd);
		        printf("查到的用户如下:\n"); 
				printf(" 编号  用户名  权限     已经使用空间        总空间           注册时间 \n");
				break;
		case 2: printf("所有用户如下:\n"); 
				printf(" 编号  用户名  权限     已经使用空间        总空间           注册时间 \n");
				break;
		case 3: deleteUser(sfd);break;
		case 4: updateUserCapacity(sfd);break;
		case 5: exit(0);break;
		default:
			   printf("请输入正确的项目\n");
			   goto start;
	}
	recv(sfd,&len,4,0);
	while(sum<len){
		ret=recv(sfd,buf+sum,len-sum,0);
		sum+=ret;
	}
	ret=0;
	sum=0;
	printf("%s\n",buf);
	bzero(buf,sizeof(buf));
	goto start;
}
