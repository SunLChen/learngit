#ifndef __FACTORY_H__
#define __FACTORY_H__
#include "head.h"
#include "work_que.h"

typedef void *(*pfunc)(void *);

typedef struct {
	pthread_t *pthid;//用于存放线程id
	pthread_cond_t cond;
	que_t que;
	int pthread_num;
	int start_flag;
	pfunc thread_func;
}fac,*pfac;

void factory_init(pfac,pfunc,int);
void factory_start(pfac);
int send_n(int,char *,int);
int recv_n(int,char *,int);
#endif
