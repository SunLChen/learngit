#ifndef _THREAD_H_
#define _THREAD_H_
#include "factory.h"
void *thread_handle(void *p);
#endif
