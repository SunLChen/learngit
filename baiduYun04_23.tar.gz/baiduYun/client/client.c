#include "head.h"
void user_op(int sfd){
	printf("\t\t\t--------1 登陆-----------\n");
	printf("\t\t\t--------2 注册-----------\n");
	printf("\t\t\t---请选择你要操作的方式:");
	int i=0;
	scanf_num(&i);
	int ret=send(sfd,&i,4,0);
	char buf[100]={0};
	switch(i){
		case 1:user_login(sfd);
			   //			   printf("测试\n");
			   recv(sfd,&i,4,0);
			   printf("%d\n",i);
			   if(i==1){
				   printf("验证成功！\n");
			   }
			   else if(i==0){
				   printf("管理员登陆成功\n");
				   manager(sfd);
			   }
			   else{
				   printf("验证失败！\n");
				   user_op(sfd);
			   }
			   break;
		case 2:user_register(sfd);
			   recv(sfd,&i,4,0);
			   if(i==1){

				   recv(sfd,buf,sizeof(buf),0);
				   printf("注册成功\n");
			   }else{
				   if(i==-2){
					   printf("该用户已存在\n");
				   }
				   printf("注册失败\n");
				   user_op(sfd);
			   }
			   bzero(buf,sizeof(buf));
			   break;
	}
	//	recv_n(sfd,(char *)&i,4);
	//	if(i==1){
	//		printf("验证成功\n");
	//	}else{
	//		printf("验证失败\n");
	//		user_op(sfd);
	//	}
}
int sock_init(char *argv[]){
	int sfd=socket(AF_INET,SOCK_STREAM,0);
	struct sockaddr_in sock;
	bzero(&sock,sizeof(sock));
	sock.sin_family=AF_INET;
	sock.sin_port=htons(atoi(argv[2]));
	sock.sin_addr.s_addr=inet_addr(argv[1]);

	if(connect(sfd,(struct sockaddr *)&sock,sizeof(struct sockaddr))==-1){
		perror("connect");
		close(sfd);
		return -1;
	}
	printf("connect success\n");
	return sfd;
}

int main(int argc,char *argv[]){
	if(3!=argc){
		printf("args error");
		return -1;
	}
	const char *orderlist[]={"cd","ls","puts","gets","remove","pwd","mkdir","search","cap"};

	int sfd=sock_init(argv);
	int ret;
	char order[50];
	char temp[10];
	char temp1[60];
	char msg[1000];
	int i=0;
	int j=0;
	//	printf("进入验证阶段\n");
	user_op(sfd);
	//	printf("以出验证阶段\n");
	fflush(stdout);
	int orderlen=0;
	while(1){
		bzero(order,sizeof(order));
		bzero(temp,sizeof(temp));
		bzero(temp1,sizeof(temp1));
		bzero(msg,sizeof(msg));
		ret=read(0,order,sizeof(order)-1);
		if(0>=ret){
			perror("read");
			goto end;
		}
		for(i=0;i<strlen(order)&&order[i]!=' '&&order[i]!='\n';i++){
			temp[i]=order[i];
		}
		i++;
		for(j=0;i<strlen(order)&&order[i]!='\n';i++,j++){
			temp1[j]=order[i];
		}
		temp1[j]='\0';
		if(strlen(temp1)==0){
			temp1[0]='.';
			temp1[1]='\0';
		}
		for(j=0;j<9;j++){
			if(strcmp(temp,orderlist[j])==0){
				sprintf(order,"%d %s",j,temp1);
				orderlen=strlen(order);
				ret=send(sfd,&orderlen,4,0);
				ret=send(sfd,order,strlen(order),0);
				if(ret<=0){
					goto end;
				}
				break;
			}
		}
		//	ret=recv(sfd,msg,sizeof(msg),0);
		if(j>8){
			printf("无此命令\n");
		}
		else if(j!=2&&j!=3&&j!=7&&j!=8){
			ret=recv(sfd,msg,sizeof(msg),0);
			printf("%s\n",msg);

		}
		else if(j==8){
			bzero(msg,sizeof(msg));
			ret=recv(sfd,msg,sizeof(msg),0);
			long useCapacity=0;//使用空间
			long Capacity=0;//总空间
			sscanf(msg,"%ld %ld",&useCapacity,&Capacity);//字符串转long int
			double percent=((double)useCapacity*100)/Capacity;//计算百分比
			int c_cap=(int)(Capacity/(1024*1024*1024));//转换单位
			double u_cap=useCapacity;
			int i=0;
			while((u_cap/1024)>1024){
				u_cap/=1024;
				i++;
			}
			if(i==0){
				printf("空间使用情况：%fB/%dGB \n百分比：%2.2f %%\n",u_cap,c_cap,percent);	
			}else if(i==1){
				printf("空间使用情况：%2.2fkB/%dGB \n百分比：%2.2f %%\n",u_cap,c_cap,percent);	
			}else if(i==2){
				printf("空间使用情况：%2.2fMB/%dGB \n百分比：%2.2f %%\n",u_cap,c_cap,percent);		
			}else{
				printf("空间使用情况：%2.2fGB/%dGB \n百分比：%2.2f %%\n",u_cap,c_cap,percent);	
			}	
	}
	else if(j==2){
		ret=tran_file(sfd,".",temp1);
		if(ret==1){
			printf("上传成功！\n");
		}else{
			printf("上传失败！\n");
			ret=0;
		}
	}else if(j==3){
		ret=gets_file(sfd,temp1);
		if(ret==0){
			printf("文件传输成功！\n");
		}	
		ret=6;	
	}else{
		int templen=0;
		ret=recv(sfd,&templen,4,0);
		if(0>=ret){
			printf("查找失败！");
			goto end;
		}
		ret=0;
		while(ret<templen){
			ret=recv(sfd,msg+ret,templen-ret,0);
			ret+=ret;
		}
		printf("%s\n",msg);

	}

	if(ret<0){
		goto end;
	}
}
end:
close(sfd);
}
