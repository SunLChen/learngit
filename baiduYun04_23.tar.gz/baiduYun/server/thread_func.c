#include "thread.h"

void *thread_handle(void *p){
	char *path=(char *)malloc(1000);
	FILE *fp;
	char logPath[60]={0};
	char buf[100];	
	char Mf='N';
	pfac pf=(pfac)p;
	pque_t pq=&pf->que;
	pnode_t pcur;
	while(1){
		bzero(path,sizeof(path));
		pthread_mutex_lock(&pq->que_mutex);
		if(!pq->que_size){
			pthread_cond_wait(&pf->cond,&pq->que_mutex);
		}
		que_get(pq,&pcur);
		pthread_mutex_unlock(&pq->que_mutex);
		int ret=0;
		int temp;
		char *name=(char *)malloc(20);
user:
		temp=recv(pcur->new_fd,&ret,4,0);
		if(temp<=0){
			perror("recv");
			return NULL;
		}
		sprintf(path,"%s","./home");
		sprintf(logPath,"%s","./log/");
		switch(ret){
			case 1:ret=user_login(pcur->new_fd,&name);
				   send(pcur->new_fd,&ret,4,0);
				   if(1==ret){
					   sprintf(logPath,"%s%s",logPath,name);
					   fp=creatFile(logPath);
					   bzero(logPath,sizeof(logPath));
					   sprintf(logPath,"%s  %s",name,"login");
					   writeFile(fp,logPath);
				   }else if(0==ret){
					   admin(pcur->new_fd);
						Mf='Y';//标记是管理员用户
				   }else{
					   goto user;
				   }
					break;
			case 2:ret=user_register(pcur->new_fd,&name); 
				   send(pcur->new_fd,&ret,4,0);
				   if(1==ret){	   			
				   		mkdir_c(pcur->new_fd,path,name);
					   sprintf(logPath,"%s%s",logPath,name);
					   fp=creatFile(logPath);
					   bzero(logPath,sizeof(logPath));
					   sprintf(logPath,"%s  %s",name,"register");
					 //  printf("%s\n",logPath);
					   writeFile(fp,logPath);
					   
					   break;
				   }else{
					   goto user;
				   }
		}
		char order[100]={0};
		int orderlen=0;
		ret=8;
		const char *orderlist[]={"cd","ls","puts","gets","remove","pwd","mkdir","search","cap"};
		char fileflag;
		sprintf(path,"%s/%s",path,name);
		while(Mf=='N'){
			bzero(buf,sizeof(buf));
			recv(pcur->new_fd,&orderlen,4,0);
			temp=recv(pcur->new_fd,buf,orderlen,0);
			sscanf(buf,"%d %s",&ret,order);
			bzero(logPath,sizeof(logPath));
			sprintf(logPath,"%s  %s",orderlist[ret],order);
			writeFile(fp,logPath);
			if(temp<=0){
				fclose(fp);
				free(name);
				break;
			}
			switch(ret){
				case 0:cd(pcur->new_fd,&path,order);break;
				case 1:ls(pcur->new_fd,path);break;
				case 2: recv(pcur->new_fd,&fileflag,1,0);
					   if(fileflag=='Y')
					   		gets_file(pcur->new_fd,path,order,name);break;
				case 3:tran_file(pcur->new_fd,path,order);break;
				case 4:remove_c(pcur->new_fd,path,order,name);break;
				case 5:pwd(pcur->new_fd,path);break;
				case 6:mkdir_c(pcur->new_fd,path,order);break;
				case 7:search_c(pcur->new_fd,order,name);break;
				case 8:see_cap(pcur->new_fd,name);
				default:break;
			}
			bzero(order,sizeof(order));
		}
	}

}
