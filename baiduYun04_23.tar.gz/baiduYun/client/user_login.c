#include"head.h"
void user_login(int sfd){
	char name[20]={0};
	char saltFigure[20];
	printf("请输入姓名:\n");
	int ret=read(0,name,sizeof(name)-1);
//	printf("%s\n",name);
	if(-1==ret){
		perror("read");
		return;
	}
	int len=strlen(name)-1;
	ret=send(sfd,&len,4,0);
	ret=send(sfd,name,strlen(name)-1,0);
	if(0>=ret){
		perror("send");
		return;
	}
	char flagUser='N';
	char *passwd=getpass("请输入密码：");
	//验证用户是否存在：
	recv(sfd,&flagUser,1,0);
	if(flagUser!='N'){
		recv(sfd,saltFigure,sizeof(saltFigure),0);
	
		char *p=crypt(passwd,saltFigure);
		while(p==NULL){
			p=crypt(passwd,saltFigure);
		}
		send(sfd,p,strlen(p),0);
	}else{
		printf("该用户不存在\n");
	}
}

void user_register(int sfd){
	char name[20]={0};
	char *password;
	char saltFigure[15]={0};
	char buf[100]={0};
	printf("请输入姓名：\n");
	int ret=read(0,name,sizeof(name));
	if(-1==ret){
		perror("read");
		return;
	}
	password=getpass("请输入密码");
	char *str = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz,./;<>?$";
	int len=strlen(str);
	srand(time(NULL));
	for(int i=0;i<10;i++){
		saltFigure[i]=str[rand()%len];
	}
	char *p=crypt(password,saltFigure);
	printf("%s\n",password);
	if(p==NULL){
		p=crypt(password,saltFigure);
	}
	sprintf(buf,"%s%s\n%s",name,saltFigure,p);
//	printf("%s\n",buf);
	send(sfd,buf,strlen(buf),0);
//	printf("%d\n",sfd);
	printf("发送成功\n");
}
