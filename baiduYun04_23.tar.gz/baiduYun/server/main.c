#include "thread.h"
#include "head.h"
int main(int argc,char *argv[]){
	if(5!=argc){
		printf("./server IP PORT THREAD_NUM CAPACITY\n");
		return -1;
	}
	fac f;
	bzero(&f,sizeof(f));
	f.pthread_num=atoi(argv[3]);
	int capacity=atoi(argv[4]);
	factory_init(&f,thread_handle,capacity);
	int sfd=socket(AF_INET,SOCK_STREAM,0);
	if(-1==sfd){
		perror("socket");
		return -1;
	}
	int ret;
	struct sockaddr_in ser;
	bzero(&ser,sizeof(ser));
	ser.sin_family=AF_INET;
	ser.sin_port=htons(atoi(argv[2]));
	ser.sin_addr.s_addr=inet_addr(argv[1]);
	ret=bind(sfd,(struct sockaddr *)&ser,sizeof(ser));
	if(-1==ret){
		perror("bind");
		return -1;
	}
	factory_start(&f);
	listen(sfd,100);
	int new_fd;
	pnode_t pnew;
	pque_t pq=&f.que;
	while(1){
		new_fd=accept(sfd,NULL,NULL);
		printf("链接成功\n");
		pnew=(pnode_t)calloc(1,sizeof(node_t));
		pnew->new_fd=new_fd;
		pthread_mutex_lock(&pq->que_mutex);
		que_set(pq,pnew);
		pthread_mutex_unlock(&pq->que_mutex);
		pthread_cond_signal(&f.cond);
	}
}
