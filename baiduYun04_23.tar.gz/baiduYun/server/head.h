#ifndef __HEAD_H__
#define __HEAD_H__
#define _GNU_SOURCE

#include <sys/types.h>
#include <dirent.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>
#include <pwd.h>
#include <grp.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <strings.h>
#include <sys/select.h>
#include <sys/time.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/msg.h>
#include <signal.h>
#include <pthread.h>
#include <errno.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/epoll.h>
#include <sys/sendfile.h>
#include <mysql/mysql.h>
#include <fcntl.h>
#include <assert.h>
#include <shadow.h>
#include <crypt.h>
#include <unistd.h>
typedef struct fileTable{
	int proCatalogue;
	char fileName[20];
	char fileType[5];
	char user[20];
	char md5[33];
	char path[30];
}fTab,*pfTab;
int user_login(int,char **);
int user_register(int,char **);
int send_n(int,char *,int);
int recv_n(int,char *,int);
void cd(int,char **,char *);
void ls(int,char *);
void pwd(int,char *);
void mkdir_c(int,char *,char *);
void remove_c(int,char *,char *,char *);
void tran_file(int,char *,char *);
int gets_file(int,char *,char *,char *);
int getMD5(MYSQL*,char *,pfTab);
FILE *creatFile(char *);
void writeFile(FILE *,char *);
MYSQL *init();
int remove_file(MYSQL*,char *,char *,char *);
int proCatalog(MYSQL *,char *);
int putsFile(MYSQL *,int,char *,char *,char *,char *,long,long *);
void searchFile(MYSQL *,int,char *,char *);
void search_c(int,char *,char *);
int findSameName(MYSQL *,char *,char *);
void getsCapacity(MYSQL *,char *,long *);
void see_cap(int,char*);
void admin(int);
void searchUser(int,MYSQL *);
void seeUser(int,MYSQL *);
void deleteUser(int,MYSQL *);
void MysqlU(MYSQL *,char *,char *);
void updateUserCapacity(int,MYSQL *);
int remove_dir(const char *);
#endif
