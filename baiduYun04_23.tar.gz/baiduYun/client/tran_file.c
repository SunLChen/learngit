#include"head.h"

int tran_file(int new_fd,char *path,char *file){
	unsigned char *md5=(char *)malloc(MD5_DIGEST_LENGTH);
	bzero(md5,sizeof(md5));
	char buf[1000]={0};
	char sameName='N';
	char fileflag='Y';
	signal(SIGPIPE,SIG_IGN);
	if(NULL==file){
		printf("文件名为空！！\n");
		goto end;
	}
	
	int fd=open(file,O_RDWR);
	if(-1==fd){
		perror("open");
		fileflag='N';
		send(new_fd,&fileflag,1,0);
		goto end;
	}
		send(new_fd,&fileflag,1,0);
	recv(new_fd,&sameName,1,0);
	if(sameName!='N'){
		printf("你所要传输的文件名称在当前目录已存在！\n");
		goto end;
	}
	int ret=calculate_md5sum(file,&md5);
	if(ret==-1){
		printf("请检查文件名是否正确\n");
		goto end;
	}
//	printf("%s\n",md5);

	int len=strlen(md5);
//	printf("%d\n",len);
	ret=send(new_fd,&len,4,0);
	if(ret==-1){
		perror("send");
		goto end;
	}
	printf("准备传输文件\n");
	send(new_fd,md5,len,0);
	bzero(buf,sizeof(buf));
	char flag;

	recv(new_fd,&flag,1,0);
	if(flag=='F'){
		printf("你的存储空间不足！！\n");
		goto end;
	}
	if(flag=='N')
	{
		sprintf(buf,"%s/%s",path,file);
		printf("%s\n",buf);
		struct stat buf1;
		ret=fstat(fd,&buf1);
		if(-1==ret){
			perror("fstat");
			goto end;
		}
		printf("文件传输中......\n");
		send(new_fd,&buf1.st_size,4,0);//此文件的长度
		printf("%ld\n",buf1.st_size);
		recv(new_fd,&flag,1,0);
		if(flag=='F'){
			printf("您的空间容量不够！\n");
			goto end;
		}
		off_t sum=0;
		int tempsum=0;
		int progress=0;
		int last_char_count=0;
		
		while((ret=sendfile(new_fd,fd,&sum,buf1.st_size-sum))>0){
			tempsum+=ret;
			progress=(int)(sum*100/buf1.st_size);
			last_char_count=display_progress(progress,last_char_count);
		};
//			printf("%d\n",ret)
//		printf("%ld\n",sum);
		close(fd);
	}
	free(md5);
	return 1;
end:
	free(md5);
	return -1;
}
