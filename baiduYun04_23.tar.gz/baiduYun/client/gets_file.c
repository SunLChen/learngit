#include "head.h"
int gets_file(int sfd,char *file){
	char buf[1000]={0};
//	printf("准备接收小文件\n");
	//接收文件名
	int ret=recv(sfd,buf,1,0);
	if(-1==ret){

		perror("recv");
		printf("传输失败！\n");
		return -1;
	}
	if(buf[0]=='Y'){
		bzero(buf,sizeof(buf));
		printf("文件名验证成功\n");
		int len=0;
		int fd=open(file,O_RDWR|O_CREAT,0666);
		struct stat buf1;
		ret=fstat(fd,&buf1);
		if(-1==ret){
			perror("fstat");
			return -1;
		}
		//发送已有文件长度
		send(sfd,&buf1.st_size,4,0);
		recv(sfd,&len,4,0);
		int sum=0;
		int pipefd[2];
		int progress=0;
		int last_char_count=0;
		ret = pipe(pipefd);  //创建管道
		assert(ret != -1);

		//将connfd上的客户端数据定向到管道中
		while(sum<len){
			ret = splice(sfd, NULL, pipefd[1], NULL,
					len, SPLICE_F_MORE | SPLICE_F_MOVE);
			assert(ret != -1);
//			ret = tee(pipefd[1],pipefd[0],len,SPLICE_F_NONBLOCK);
			//将管道的输出定向到connfd上
			ret = splice(pipefd[0], NULL, fd, NULL,
					len, SPLICE_F_MORE | SPLICE_F_MOVE);
			assert(ret != -1);
			sum+=ret;
			//进度条
			progress=(int)(sum*100/len);
			last_char_count=display_progress(progress,last_char_count);
		}

		close(fd);
	}else{
		printf("获取文件失败！\n");
		return -1;
	}
	return 0;
}
