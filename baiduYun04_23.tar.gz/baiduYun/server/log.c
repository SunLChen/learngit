#include "head.h"

FILE *creatFile(char *pathName){
//	printf("%s\n",pathName);
	FILE *fp=fopen(pathName,"a+");
	if(!fp){
		return NULL;
	}
	fseek(fp,1024*1024*2-1,SEEK_SET);
	fwrite(" ",1,1,fp);
	fseek(fp,0,SEEK_SET);
	return fp;
}

void writeFile(FILE *fp,char *buf){
	char pszTimeStr[1024]={0};
	struct tm      tSysTime     = {0};
	struct timeval tTimeVal     = {0};
	time_t         tCurrentTime = {0};

	uint8_t  szUsec[20] = {0};    // 微秒
	uint8_t  szMsec[20] = {0};    // 毫秒

	tCurrentTime = time(NULL);
	localtime_r(&tCurrentTime, &tSysTime);   // localtime_r是线程安全的

	gettimeofday(&tTimeVal, NULL);    
	sprintf(szUsec, "%06ld", tTimeVal.tv_usec);  // 获取微秒
	strncpy(szMsec, szUsec, 3);                // 微秒的前3位为毫秒(1毫秒=1000微秒)

	sprintf(pszTimeStr, "[%04d.%02d.%02d %02d:%02d:%02d]  %s\n", 
			tSysTime.tm_year+1900, tSysTime.tm_mon+1, tSysTime.tm_mday,
			tSysTime.tm_hour, tSysTime.tm_min, tSysTime.tm_sec,buf);
	fwrite(pszTimeStr,strlen(pszTimeStr),1,fp);
	fflush(fp);
}
