#ifndef __HEAD_H__
#define __HEAD_H__
#define _GNU_SOURCE
#include <sys/types.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>
#include <pwd.h>
#include <grp.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <strings.h>
#include <sys/select.h>
#include <sys/time.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/msg.h>
#include <signal.h>
#include <pthread.h>
#include <errno.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/epoll.h>
#include <sys/sendfile.h>
#include <mysql/mysql.h>
#include <shadow.h>
#include <crypt.h>
#include <unistd.h>
#include <openssl/md5.h>
#include <assert.h>
void user_login(int);
void user_register(int);
int send_n(int,char*,int);
int recv_n(int,char *,int);
int gets_file(int,char *);
int tran_file(int,char*,char *);
int calculate_md5sum(char *,unsigned char **);
int display_progress(int,int);
void scanf_num(int *);
void manager(int);
#endif
