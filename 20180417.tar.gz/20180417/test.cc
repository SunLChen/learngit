 ///
 /// @file    test.cc
 /// @author  cgy(cgy@qq.com)
 /// @date    2018-04-17 19:35:17
 ///
 
#include <iostream>
using std::cout;
using std::endl;
int main(){
	char *p=new char[20]();
	cout<<strlen(p)<<endl;
}
